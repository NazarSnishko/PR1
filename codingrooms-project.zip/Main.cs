using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
    static void Main(string[] args)
    {
        int[] numbers = new int[10];
        int smallestPositive = int.MaxValue;

        Console.WriteLine("Введіть 10 чисел:");

        for (int i = 0; i < 10; i++)
        {
            if (int.TryParse(Console.ReadLine(), out numbers[i]))
            {
                if (numbers[i] > 0 && numbers[i] < smallestPositive)
                {
                    smallestPositive = numbers[i];
                }
            }
            else
            {
                Console.WriteLine("Введено некоректне число. Будь ласка, введіть число знову.");
                i--;
            }
        }

        if (smallestPositive != int.MaxValue)
        {
            Console.WriteLine("Найменше додатнє число: " + smallestPositive);
        }
        else
        {
            Console.WriteLine("У списку немає додатних чисел.");
        }
    }
    }
}
